## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(DilaPack)
hello()
mean_calc(c(1,2,3,4,5))
median_calc(c(1,2,3,4,5))

